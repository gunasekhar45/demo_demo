package com.grocery.booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryBookingBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
