package com.grocery.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroceryBookingBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroceryBookingBeApplication.class, args);
	}

}
